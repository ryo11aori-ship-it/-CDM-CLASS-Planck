#ifndef JKPL_H
#define JKPL_H

#include <wchar.h>
#include <stdlib.h>

// 命令タイプ定義
typedef enum {
    OP_INC_PTR, // > SHIN
    OP_DEC_PTR, // < TAI
    OP_INC_VAL, // + ZO
    OP_DEC_VAL, // - GEN
    OP_OUTPUT,  // . SHA
    OP_INPUT,   // , JU
    OP_JMP_FWD, // [ JUN
    OP_JMP_BCK, // ] KETSU
    OP_NONE     // 無効/パラメータ用
} OpType;

// 生成されたデータベースをここで読み込み
// 注意: このファイルがあるディレクトリで generate_db.py を実行しておく必要があります
#include "kanji_data.h"

// 検索結果用構造体
typedef struct {
    wchar_t code;
    int strokes;
    OpType op;
    long number_val;
} KanjiProp;

// 二分探索用比較関数
int compare_kanji(const void* a, const void* b) {
    wchar_t key = *(const wchar_t*)a;
    const KanjiEntry* entry = (const KanjiEntry*)b;
    if (key < entry->code) return -1;
    if (key > entry->code) return 1;
    return 0;
}

// データベース検索
KanjiProp get_kanji_prop(wchar_t c) {
    KanjiProp result = {c, 0, OP_NONE, -1};

    // マーカー文字（行・番）のハードコード
    if (c == L'行') { result.strokes = 6; result.number_val = -2; return result; }
    if (c == L'番') { result.strokes = 12; result.number_val = -3; return result; }

    // 全漢字DBから検索 (Binary Search)
    const KanjiEntry* found = (const KanjiEntry*) bsearch(
        &c,
        KANJI_DATA,
        KANJI_DATA_SIZE,
        sizeof(KanjiEntry),
        compare_kanji
    );

    if (found) {
        result.strokes = found->strokes;
        result.op = (OpType)found->op;
        result.number_val = found->number_val;
    } else {
        // 未登録漢字はデフォルト値（無効命令）
        result.strokes = 10;
    }
    
    return result;
}

#endif
