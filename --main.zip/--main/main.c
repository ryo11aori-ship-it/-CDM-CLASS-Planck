#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <wchar.h>
#include "jkpl.h"

#define MAX_CODE_SIZE 20000
#define TAPE_SIZE 30000
#define MAX_ROWS 2000
#define MAX_COLS 2000

// --- データ構造 ---

typedef struct {
    wchar_t kanji;
    OpType op;
    int target_row;
    int target_index;
    int original_index; 
} Cell;

typedef struct {
    int id;
    Cell ops[MAX_COLS];
    int count;
    double avg_strokes;
    wchar_t first_char;
} ProteinRow;

// グローバル変数
Cell raw_input[MAX_CODE_SIZE];
int raw_input_count = 0;

ProteinRow rows[MAX_ROWS];
int active_rows_count = 0;

OpType final_program[MAX_CODE_SIZE];
int program_length = 0;

// --- 数値解析 ---
long parse_japanese_number(const wchar_t* str, int* len_out) {
    long total = 0;
    long current = 0;
    int i = 0;
    
    while (str[i] != L'\0') {
        KanjiProp p = get_kanji_prop(str[i]);
        if (p.number_val == -2 || p.number_val == -3 || str[i] == L'間' || str[i] == L'改') break;
        
        if (p.number_val >= 0) {
            if (p.number_val >= 10) { 
                if (current == 0) current = 1;
                total += current * p.number_val;
                current = 0;
            } else {
                current = p.number_val;
            }
        }
        i++;
    }
    total += current;
    *len_out = i;
    return total;
}

// --- パーサー ---
void parse_source(const wchar_t* src) {
    int len = wcslen(src);
    int i = 0;
    wchar_t last_main_kanji = 0;

    while (i < len) {
        if (src[i] != L'間') { i++; continue; }
        i++; // skip 間

        if (src[i] == L'\0' || src[i] == L'間') continue;

        wchar_t main_kanji = src[i];
        
        // Unicode順序チェック
        if (last_main_kanji != 0 && main_kanji < last_main_kanji) {
            fwprintf(stderr, L"Error: Unicode Sort Violation! %lc (U+%04X) < %lc (U+%04X)\n", 
                main_kanji, main_kanji, last_main_kanji, last_main_kanji);
            exit(1);
        }
        last_main_kanji = main_kanji;
        
        KanjiProp prop = get_kanji_prop(main_kanji);
        Cell cell;
        cell.kanji = main_kanji;
        cell.op = prop.op;
        cell.original_index = raw_input_count;
        
        i++; 

        int parsed_len = 0;
        long row_num = parse_japanese_number(&src[i], &parsed_len);
        i += parsed_len;
        if (src[i] == L'行') {
            i++;
            cell.target_row = (row_num == 0 && parsed_len == 0) ? 0 : row_num;
        } else {
            cell.target_row = 0; 
        }

        long col_num = parse_japanese_number(&src[i], &parsed_len);
        i += parsed_len;
        if (src[i] == L'番') {
            i++;
            cell.target_index = (col_num == 0 && parsed_len == 0) ? 0 : col_num;
        } else {
            cell.target_index = 0;
        }

        if (src[i] == L'改') i++;
        while(src[i] != L'間' && src[i] != L'\0') i++;

        if (raw_input_count < MAX_CODE_SIZE) {
            raw_input[raw_input_count++] = cell;
        }
    }
}

// --- アセンブリ ---
void assemble_rows() {
    for(int i=0; i<MAX_ROWS; i++) {
        rows[i].id = i;
        rows[i].count = 0;
        rows[i].avg_strokes = 0.0;
        rows[i].first_char = 0xFFFF;
    }

    int max_row_idx = 0;

    for (int i=0; i<raw_input_count; i++) {
        Cell c = raw_input[i];
        int r = c.target_row;
        int idx = c.target_index;
        
        if (r >= MAX_ROWS || idx >= MAX_COLS) continue; 
        if (r > max_row_idx) max_row_idx = r;
        
        rows[r].ops[idx] = c;
        if (idx >= rows[r].count) rows[r].count = idx + 1;
        if (idx == 0) rows[r].first_char = c.kanji;
    }
    
    active_rows_count = max_row_idx + 1;
}

// --- 電気泳動 (ソート) ---
int compare_rows(const void* a, const void* b) {
    ProteinRow* ra = (ProteinRow*)a;
    ProteinRow* rb = (ProteinRow*)b;

    if (ra->count == 0 && rb->count == 0) return 0;
    if (ra->count == 0) return 1;
    if (rb->count == 0) return -1;

    // 1. 平均画数（昇順）
    if (ra->avg_strokes < rb->avg_strokes) return -1;
    if (ra->avg_strokes > rb->avg_strokes) return 1;

    // 2. 先頭文字のUnicode順
    if (ra->first_char < rb->first_char) return -1;
    if (ra->first_char > rb->first_char) return 1;

    return 0;
}

void perform_electrophoresis() {
    for (int r = 0; r < active_rows_count; r++) {
        if (rows[r].count == 0) continue;
        
        long total_strokes = 0;
        int valid_chars = 0;
        
        for (int c = 0; c < rows[r].count; c++) {
            wchar_t k = rows[r].ops[c].kanji;
            if (k != 0) {
                total_strokes += get_kanji_prop(k).strokes;
                valid_chars++;
            }
        }
        
        if (valid_chars > 0) {
            rows[r].avg_strokes = (double)total_strokes / valid_chars;
        } else {
            rows[r].avg_strokes = 0;
        }
    }

    qsort(rows, active_rows_count, sizeof(ProteinRow), compare_rows);
}

// --- フラット化 ---
void flatten_program() {
    for (int r = 0; r < active_rows_count; r++) {
        if (rows[r].count == 0) continue;
        for (int c = 0; c < rows[r].count; c++) {
            if (rows[r].ops[c].kanji != 0) {
                final_program[program_length++] = rows[r].ops[c].op;
            }
        }
    }
}

// --- VM実行 ---
void execute_vm() {
    unsigned char tape[TAPE_SIZE] = {0};
    int ptr = 0;
    int pc = 0;
    
    while (pc < program_length) {
        OpType op = final_program[pc];
        
        switch (op) {
            case OP_INC_PTR: ptr++; if(ptr>=TAPE_SIZE) ptr=0; break;
            case OP_DEC_PTR: ptr--; if(ptr<0) ptr=TAPE_SIZE-1; break;
            case OP_INC_VAL: tape[ptr]++; break;
            case OP_DEC_VAL: tape[ptr]--; break;
            case OP_OUTPUT:  putchar(tape[ptr]); break;
            case OP_INPUT:   tape[ptr] = getchar(); break;
            case OP_JMP_FWD:
                if (tape[ptr] == 0) {
                    int loop = 1;
                    while (loop > 0) {
                        pc++;
                        if (pc >= program_length) break;
                        if (final_program[pc] == OP_JMP_FWD) loop++;
                        if (final_program[pc] == OP_JMP_BCK) loop--;
                    }
                }
                break;
            case OP_JMP_BCK:
                if (tape[ptr] != 0) {
                    int loop = 1;
                    while (loop > 0) {
                        pc--;
                        if (pc < 0) break;
                        if (final_program[pc] == OP_JMP_BCK) loop++;
                        if (final_program[pc] == OP_JMP_FWD) loop--;
                    }
                }
                break;
            default: break;
        }
        pc++;
    }
}

int main(int argc, char** argv) {
    setlocale(LC_ALL, ""); 
    
    if (argc < 2) {
        fprintf(stderr, "JKPL v2.0\nUsage: jkpl.exe <source_file>\n");
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (!fp) { perror("File open error"); return 1; }

    wchar_t buffer[MAX_CODE_SIZE];
    size_t len = 0;
    
    // シンプルな読み込み (UTF-8環境を想定)
    // Windowsの場合、実行ファイルの入力ファイルはUTF-8(BOMなし)で保存してください
    while(fgetws(buffer + len, MAX_CODE_SIZE - len, fp)) {
        len += wcslen(buffer + len);
    }
    fclose(fp);

    parse_source(buffer);
    assemble_rows();
    perform_electrophoresis();
    flatten_program();
    execute_vm();

    return 0;
}
