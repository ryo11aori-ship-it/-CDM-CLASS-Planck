import requests
import zipfile
import io

# 定義: 音読み(ローマ字) と JKPL命令の対応
OP_MAP = {
    "SHIN":  "OP_INC_PTR", # > 進
    "TAI":   "OP_DEC_PTR", # < 退
    "ZO":    "OP_INC_VAL", # + 増
    "ZOU":   "OP_INC_VAL", 
    "GEN":   "OP_DEC_VAL", # - 減
    "SHA":   "OP_OUTPUT",  # . 写
    "JU":    "OP_INPUT",   # , 受
    "JUU":   "OP_INPUT",
    "JUN":   "OP_JMP_FWD", # [ 巡
    "KETSU": "OP_JMP_BCK"  # ] 結
}

# 定義: 数値としての漢字 (優先的にハードコード)
NUM_MAP = {
    0x96F6: 0,      # 零
    0x4E00: 1,      # 一
    0x4E8C: 2,      # 二
    0x4E09: 3,      # 三
    0x56DB: 4,      # 四
    0x4E94: 5,      # 五
    0x516D: 6,      # 六
    0x4E03: 7,      # 七
    0x516B: 8,      # 八
    0x4E5D: 9,      # 九
    0x5341: 10,     # 十
    0x767E: 100,    # 百
    0x5343: 1000,   # 千
    0x4E07: 10000,  # 万
}

def download_unihan():
    url = "https://www.unicode.org/Public/UCD/latest/ucd/Unihan.zip"
    print(f"Downloading {url} ...")
    r = requests.get(url)
    return zipfile.ZipFile(io.BytesIO(r.content))

def parse_unihan(z):
    kanji_db = {}

    # 1. 画数 (Unihan_DictionaryLikeData.txt)
    print("Parsing stroke counts...")
    with z.open("Unihan_DictionaryLikeData.txt") as f:
        for line in io.TextIOWrapper(f, encoding="utf-8"):
            if line.startswith("#") or not line.strip(): continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            if parts[1] == "kTotalStrokes":
                code = int(parts[0][2:], 16)
                strokes = int(parts[2].split(" ")[0])
                if code not in kanji_db: kanji_db[code] = {"strokes": 0, "op": "OP_NONE", "num": -1}
                kanji_db[code]["strokes"] = strokes

    # 2. 読み (Unihan_Readings.txt)
    print("Parsing readings...")
    with z.open("Unihan_Readings.txt") as f:
        for line in io.TextIOWrapper(f, encoding="utf-8"):
            if line.startswith("#") or not line.strip(): continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            if parts[1] == "kJapaneseOn":
                code = int(parts[0][2:], 16)
                if code not in kanji_db: continue
                readings = parts[2].strip().split(" ")
                for r in readings:
                    if r in OP_MAP:
                        kanji_db[code]["op"] = OP_MAP[r]
                        break

    # 3. 数値情報のマージ
    for code, val in NUM_MAP.items():
        if code not in kanji_db:
            kanji_db[code] = {"strokes": 5, "op": "OP_NONE", "num": -1}
        kanji_db[code]["num"] = val

    return kanji_db

def generate_header(db):
    print("Generating kanji_data.h ...")
    sorted_codes = sorted(db.keys())
    
    with open("kanji_data.h", "w", encoding="utf-8") as f:
        f.write("#ifndef KANJI_DATA_H\n#define KANJI_DATA_H\n\n")
        f.write("#include <wchar.h>\n\n")
        
        f.write("typedef struct {\n")
        f.write("    wchar_t code;\n")
        f.write("    unsigned char strokes;\n")
        f.write("    unsigned char op;\n")
        f.write("    long number_val;\n")
        f.write("} KanjiEntry;\n\n")
        
        f.write(f"static const int KANJI_DATA_SIZE = {len(sorted_codes)};\n")
        f.write("static const KanjiEntry KANJI_DATA[] = {\n")
        
        for code in sorted_codes:
            entry = db[code]
            # opは文字列定数(enum)なのでそのまま出力
            f.write(f"    {{0x{code:X}, {entry['strokes']}, {entry['op']}, {entry['num']}}},\n")
            
        f.write("};\n\n")
        f.write("#endif\n")

if __name__ == "__main__":
    try:
        z = download_unihan()
        db = parse_unihan(z)
        generate_header(db)
        print("Done!")
    except Exception as e:
        print(f"Error: {e}")
        exit(1)
